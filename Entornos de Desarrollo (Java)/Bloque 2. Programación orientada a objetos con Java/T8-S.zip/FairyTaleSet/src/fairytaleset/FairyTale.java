package fairytaleset;

import java.util.Objects;

public class FairyTale 
{
    String title;
    int pages;

    public FairyTale(String title, int pages) {
        this.title = title;
        this.pages = pages;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    @Override
    public String toString() {
        return "FairyTale{" + "title=" + title + ", pages=" + pages + '}';
    }

    @Override
    public boolean equals(Object o) {
        FairyTale f = (FairyTale)o;
        return this.getTitle().equals(f.getTitle());
    }   

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + Objects.hashCode(this.title);
        return hash;
    }
}
